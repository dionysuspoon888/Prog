<?php
# validate.php
echo "<p>";
echo "Your name is " . $_POST['name'] . "<br/>";
echo "Your email: " . $_POST['email'];
echo "</p>";
?>


