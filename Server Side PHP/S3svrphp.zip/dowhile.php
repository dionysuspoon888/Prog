<?php  
$x1=1;  
do {  
  echo "Increment Number : $x1 <br />";  
  echo "Hello World  <br />";  
  $x1=$x1+1;  
} while ($x1<=5)  
?>  
