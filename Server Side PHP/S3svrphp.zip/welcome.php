<html>
<head>
  <title>Welcome</title>
</head>
<body>
<!-- Retrieve by $_POST -->
Welcome <?php echo $_POST["fname"]; ?>!<br />
You are <?php echo $_POST["age"]; ?> years old.
</body>
</html>