<?php
# switch.php
$xint=3;  
switch($xint) {  
case 1:  
  echo "This is case No 1.";  
  break;  
case 2:  
  echo "This is case No 2.";  
  break;  
case 3:  
  echo "This is case No 3.";  
  break;  
default:  
  echo "This is default.";  
}  
?>  
