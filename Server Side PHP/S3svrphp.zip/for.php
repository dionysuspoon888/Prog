<?php
# for.php  
for ($xint=0; $xint<=5; $xint++)  
{  
echo "Number is : $xint <br/>";  
}  
?>  
