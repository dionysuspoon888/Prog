<?php
# str.php
$b = 'Hello ' .'World';
echo "$b\$b<br />";
echo '$b\$b<br />';
echo "$b{4}<br />";
echo "The 5th char:" . $b{4} . '<br />';
?>
