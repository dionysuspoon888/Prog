<?php
# eqops.php
$a = 1;
$b = "1";
echo ($a == $b)? "TRUE":"FALSE";
echo "<br/>";
echo ($a === $b)? 'TRUE':'FALSE';
?>
