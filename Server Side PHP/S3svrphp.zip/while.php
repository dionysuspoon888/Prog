<?php
# while.php
$x1=1;
while ($x1<=5)
{
  echo "Increment Number : $x1 <br />";
  echo "Hello World <br />";
  $x1=$x1+1;
}
?>
